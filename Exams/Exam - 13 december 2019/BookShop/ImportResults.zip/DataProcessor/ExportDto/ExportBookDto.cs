﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ExportDto
{
    public class ExportBookDto
    {

        public string BookName { get; set; }
        public string BookPrice { get; set; }
    }
}
