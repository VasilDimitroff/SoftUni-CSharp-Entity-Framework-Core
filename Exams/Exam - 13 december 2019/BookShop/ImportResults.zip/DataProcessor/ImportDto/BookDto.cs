﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{
    public class BookDto
    {
        public int? Id { get; set; }
    }
}
