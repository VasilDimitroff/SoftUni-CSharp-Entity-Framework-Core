﻿namespace VaporStore.Data
{
	using Microsoft.EntityFrameworkCore;
    using System;
    using VaporStore.Data.Models;

    public class VaporStoreDbContext : DbContext
	{
		public VaporStoreDbContext()
		{
		}

		public VaporStoreDbContext(DbContextOptions options)
			: base(options)
		{
		}

		protected override void OnConfiguring(DbContextOptionsBuilder options)
		{
			if (!options.IsConfigured)
			{
				options
					.UseSqlServer(Configuration.ConnectionString);
			}
		}

		protected override void OnModelCreating(ModelBuilder model)
		{
			//model.Entity<Game>(entity =>
			//{
			//	entity.HasKey(e => e.Id);
			//	entity.HasCheckConstraint("Game_Price","[Price] >= 0");
			//});

			model.Entity<GameTag>(entity =>
			{
				entity.HasKey(e => new {  e.GameId, e.TagId });

				entity.HasOne(e => e.Game)
				.WithMany(g => g.GameTags)
				.HasForeignKey(e => e.GameId)
				.OnDelete(DeleteBehavior.Restrict);

				entity.HasOne(e => e.Tag)
				.WithMany(t => t.GameTags)
				.HasForeignKey(e => e.TagId)
				.OnDelete(DeleteBehavior.Restrict);
			});

			model.Entity<User>(entity =>
			{

				entity.Property(e => e.FullName).IsUnicode(false);
				entity.Property(e => e.Email).IsUnicode(false);

			});

			model.Entity<Purchase>(entity =>
			{

				entity.Property(e => e.ProductKey).IsUnicode(false);

			});

		}

    }
}