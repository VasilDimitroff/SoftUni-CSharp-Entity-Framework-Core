﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VaporStore.DataProcessor.Dto.Import
{
    public class ImportTagDto
    {
        public string Name { get; set; }
    }
}
